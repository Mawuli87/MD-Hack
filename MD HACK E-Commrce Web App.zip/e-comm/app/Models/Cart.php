<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    use HasFactory;
    //normally if the model is always singular 
   // and table name plural.but in this case both are singular so what we can do
   //is to define the table here then it will work fine
    public $table="cart";

}
