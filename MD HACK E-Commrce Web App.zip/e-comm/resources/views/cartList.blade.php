@extends('master')
@section('content')
    

<div class="custom-product custom-product-cart">
  
 <div class="col-sm-12">
   
    <div class="trending-wrapper">
        <h2 id="cart-user">{{Session::get('user')['name']}} Cart Items</h2>
        <a href="ordernow"><button class="btn btn-success btn-order">Order Now</button></a>
       
        @foreach($products as $item)
        <div class=" row searched-item cart-list-divider">
         <div class="col-sm-3">

            <a href="detail/{{$item->id}}">
                <img class="trending-img" src="{{$item->gallery}}">
         </div>


         <div class="col-sm-6 cart-text">

            <a href="detail/{{$item->id}}">
               
                <h3>{{$item->name}}</h3>
               </a>
                <div class="">
               
                 <p>{{$item->description}}</p>
               
               </div>

         </div>


         <div class="col-sm-3 cart-remove">
               <a href="/removecart/{{$item->cart_id}}" class="btn btn-danger">Delete item </a>
         </div>

         
       </div>
       @endforeach
       <a href="ordernow"><button class="btn btn-success btn-order">Order Now</button></a>
    </div>  
 </div>
       
</div>
        
      
@endsection