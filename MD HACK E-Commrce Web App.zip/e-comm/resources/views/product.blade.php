@extends('master')
@section('content')
    

<div class="custom-product">

    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
      
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
       @foreach ($products as $item)
      
       <div  class="item {{$item['id']==22?'active':''}}">
        <a  href="detail/{{$item['id']}}" id="imgid">
          <img class="slider-img" src="{{$item['gallery']}}">
        </a>
       
         <!-- This is a jumbotron -->
         <div id="home">

        <div class="carousel-caption slider-text">
          <h3>{{$item['name']}}</h3> 
          {{-- <p>{{$item['description']}}</p> --}}
            <p><a class="btn"href="detail/{{$item['id']}}">Buy this item</a></p>
            
        </div>
      


         
          

          <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
          </a>

          <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
          </a>
         
        </div>

      </div>
      @endforeach
    </div>

   
      <div class="trending-wrapper">
        <h3 id="trendMark">Available Products</h3>
        @foreach($products as $item)
        <div class="trending-item">
          <a href="detail/{{$item['id']}}">
         <img class="trending-img" src="{{$item['gallery']}}">
         <h3>{{$item['name']}}</h3>
        </a>
         <div class="">
         
          <h3>Ghc {{$item['price']}}</h3>
        
        </div>
         

       </div>
       @endforeach
      </div>  

       
        </div>
        
      
       <!-- Left and right controls -->

</div>


@endsection