     <div class="botton-footer" style="clear: both;" >



     
            <div class="row">
              <div class="col-sm-4">
                <p class="footer-text" href="#">&copy; Copyright 2020.Developped by Koffi Nyonouglo</p>
              </div>
              
              <div class="col-sm-8">
              

                    <h4 href="" class="typewrite" data-period="2000" data-type='[ "Hi, Im Kofi Nyonouglo,From Ghana Accra.", "My project is an E-commerce platform where people .", "can shop online, add items to cart, place orders and track orders to be delevered to them.", "We have products like Mobile Phones, TV gadgets,Game Laptops and many more...","We are here to serve you.just shop,add items to cart,place order and wait for your orders to be delevered to you..Thanks for choosing us." ]'>
                    </h4>
                


               </div>
              </div>
            </div>
        
  
    
    </div>