@extends('master')
@section('content')
    

<div class="custom-product custom-product-cart">
  
 <div class="col-sm-12">
   
    <div class="trending-wrapper">
        <h2 id="cart-user">{{Session::get('user')['name']}} Orders</h2>
     
       
        @foreach($orders as $item)
        <div class=" row searched-item cart-list-divider">
         <div class="col-sm-3">

            <a href="detail/{{$item->id}}">
                <img class="trending-img" src="{{$item->gallery}}">
            </a>
         </div>


         <div class="col-sm-6 cart-text">

           
                <div class="">
               
                 <h3>Name :{{$item->name}}</h3>
                 <p>Delivery status :{{$item->status}}</p>
                 <p>address :{{$item->address}}</p>
                 <p>Payment Status :{{$item->payment_status}}</p>
                 <p>Payment Method :{{$item->payment_method}}</p>
                 
               
               </div>

         </div>


         
         
       </div>
       @endforeach
    
    </div>  
 </div>
       
</div>
        
      
@endsection