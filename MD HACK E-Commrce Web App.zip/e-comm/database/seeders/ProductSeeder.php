<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('products')->insert([
                [
                    'name'=>'Apple Mobile',
                 "price"=>"700",
                 "description"=>"A smartphone with 24gb ram and much more features.Xaomi is a great phone",
                 "category"=>"apple",
                 "gallery"=>"http://onlineus.info/img/apple2.jpg"
                ],
                [
                    'name'=>'Huawai Mobile',
                 "price"=>"700",
                 "description"=>"A smartphone with 24gb ram and much more features.Xaomi is a great phone",
                 "category"=>"Huawai",
                 "gallery"=>"http://onlineus.info/img/huawai2.jpg"
                ],
                [
                'name'=>'Meizu Mobile',
                 "price"=>"700",
                 "description"=>"A smartphone with 24gb ram and much more features.Xaomi is a great phone",
                 "category"=>"Meizu",
                 "gallery"=>"http://onlineus.info/img/xiaomi4.jpg"
                ],

                [
                    'name'=>'Samsung Mobile',
                 "price"=>"1200",
                 "description"=>"A smartphone with 24gb ram and much more features.Xaomi is a great phone",
                 "category"=>"Xiaomi",
                 "gallery"=>"http://onlineus.info/img/samsung1.jpg"
                ],

            ]);
    }
}
