
<?php $__env->startSection('content'); ?>
    

<div class="custom-product">
  <div class="col-sm-4">
    <a href="#">Filter</a>
  </div>
 <div class="col-sm-8">
   
    <div class="trending-wrapper">
        <h2>Result For Products</h2>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="searched-item">
          <a href="detail/<?php echo e($item['id']); ?>">
         <img class="trending-img" src="<?php echo e($item['gallery']); ?>">
         <h3><?php echo e($item['name']); ?></h3>
        </a>
         <div class="">
          <h3><?php echo e($item['name']); ?></h3>
          <h3><?php echo e($item['description']); ?></h3>
        
        </div>
         
       </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>  
 </div>
       
</div>
        
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mawuli\tuto\e-comm\resources\views/search.blade.php ENDPATH**/ ?>