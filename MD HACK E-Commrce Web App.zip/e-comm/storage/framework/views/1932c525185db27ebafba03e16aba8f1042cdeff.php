
<?php $__env->startSection('content'); ?>
    

<div class="custom-product custom-product-cart">
  
 <div class="col-sm-10 ">
    <table class="table">
       
        <tbody>
          <tr>
            <td>Amount</td>
            <td>$<?php echo e($total); ?></td>
          </tr>
          <tr>
            <td>Tax</td>
            <td>$ 0</td>
          </tr>
          <tr>
            <td>Delevery</td>
            <td>$ 10</td>
        
          </tr>
          <tr>
            <td>Total Amount =</td>
            <td>$<?php echo e($total+ 10); ?></td>
        
          </tr>
        </tbody>
      </table>
    </div>
    <form action="/orderplaced" method="POST">
      <?php echo csrf_field(); ?>
    <div class="form-group">
     <textarea name="address" placeholder="Enter your address" class="form-control"></textarea>
    </div>
    <div class="form-group">
      <label for="pwd">Payment Method</label>&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="radio" value="cash" name="payment">&nbsp;<span>Online payment</span>&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="radio" value="cash" name="payment">&nbsp;<span>EMI payment</span>&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="radio" value="cash" name="payment">&nbsp;<span>Payment on Delivery</span>
    </div>
    <button type="submit" class="btn btn-default">Order Now</button>
    </form>
  
 </div>
       
</div>
        
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mawuli\tuto\e-comm\resources\views/ordernow.blade.php ENDPATH**/ ?>