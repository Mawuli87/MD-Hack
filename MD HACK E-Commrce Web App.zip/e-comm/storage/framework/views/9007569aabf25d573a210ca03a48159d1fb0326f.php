<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>E-commerce Project</title>
        <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    
    
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
   
    <style>
      
    
      
        .custom-product {
            /* height: auto;
            background-image: url('<?php echo e(asset('img/nature.mp4')); ?>') !important;
            background-attachment: fixed;
            background-size: cover;
             */
           
         
        }
        
        .carousel-inner{
           
            background-image: url('<?php echo e(asset('img/whiteboard.jpg')); ?>');
            background-attachment: fixed;
            background-size: cover;
            margin-top: 4%;
        
        }
        
        #imgid {
            background-color: rgb(167, 106, 14);
        }
        .img.slider-img {
            align-items: center;
        }
        .trending-img {
            height: 280px;
        }
        .trending-item {
            float: right;
            width: 30%;
            margin: 1rem;
        }
        .trending-wrapper {
          
            margin:auto;
          
          
        }
        #trendMark{
            text-decoration: underline;
            margin-left: 9rem;
            margin-bottom: 3rem;
            
        }
        .carousel-inner .item img {
        height: 300px;
         margin: 0 auto;
      
        
       
         }
         .carousel-caption {
          position: relative;
          color: black;
          left: auto;
          right: auto;
          height: 200px;
       } 
         body{
        color:black;
       
        background-color:#ffffff;
        background-attachment: fixed;
        background-size: cover;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin-bottom: 80px;
        

      }
      .container{
        margin-top: 5%;
      }



     #home{

     text-align: center;
   
      width: 900px;
    
      margin-left: 17%;
      color: white;
     border-radius: 70px;
     text-align: center;
     padding: 0px;
     letter-spacing: 1px;
     
    
   
    }
    #trendMark{
        margin-top:5rem;
        font-size: 30px;
        font-family: fantasy;
    }
    
    #home .btn{
    background-color: brown;
    color: white;
    font-size: 30px;
    font-family: fantasy;
    letter-spacing: 2px;
    border-radius: 10px;
   
}  

.detail-img {
    margin-top: 4%;
    height: 400px;
}
.search-box {
    width: 500px !important;
}



/* html{
   background-image: url('<?php echo e(asset('img/nature.mp4')); ?>');
   background-attachment: fixed;
    background-size: cover;
     background-image: url('<?php echo e(asset('img/nature.jpg')); ?>');
    z-index::backdrop;
    }
    */
    
    .cart-list-divider {
        border-bottom: 2px solid #cccccc;
        
        
    }
    .custom-product-cart {

        margin-top: 5%;
        padding-left: 20px;
        padding-right: 20px;
        
    }
    .cart-remove {
        margin-top: 6%;
       text-align: right;
       padding-right: 60px;
       
    }
    .cart-text {
       margin-top: 20px;

        text-align:justify;
        padding-left: 50px;
    }
    #cart-user{
        margin-left: 10%;
    }
    .btn-order {
        float: right;
    }
    
    .botton-footer{
        text-align: center;
    position: fixed;
    height: auto;
    background-color:#cccccc;
    bottom: 0px;
    left: 0px;
    right: 0px;
    margin-bottom: 0px;
    }
    .botton-footer p{
        margin-top: 20px;
        font-size: 16px;
        font-weight: bolder;
        color: black;
        padding-left: 30px;
      
    }
    .botton-footer h4 {
        margin-top: 15px;
        color: maroon;
        font-weight: bolder;
    }
    .body-p{
        background-color: maroon;
        margin-top: 20px;
        height: 50px;
        border-radius: 20px;
        color: #ffffff;
    }
    .body-p p {
        margin-bottom: 20px;
    }
    </style>

<body>
    <?php echo e(View::make('header')); ?>

        <?php echo $__env->yieldContent('content'); ?>
  
    <?php echo e(View::make('footer')); ?>

    
</body>


<script>

var TxtType = function(el, toRotate, period) {
        this.toRotate = toRotate;
        this.el = el;
        this.loopNum = 0;
        this.period = parseInt(period, 10) || 2000;
        this.txt = '';
        this.tick();
        this.isDeleting = false;
    };

    TxtType.prototype.tick = function() {
        var i = this.loopNum % this.toRotate.length;
        var fullTxt = this.toRotate[i];

        if (this.isDeleting) {
        this.txt = fullTxt.substring(0, this.txt.length - 1);
        } else {
        this.txt = fullTxt.substring(0, this.txt.length + 1);
        }

        this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

        var that = this;
        var delta = 200 - Math.random() * 100;

        if (this.isDeleting) { delta /= 2; }

        if (!this.isDeleting && this.txt === fullTxt) {
        delta = this.period;
        this.isDeleting = true;
        } else if (this.isDeleting && this.txt === '') {
        this.isDeleting = false;
        this.loopNum++;
        delta = 500;
        }

        setTimeout(function() {
        that.tick();
        }, delta);
    };

    window.onload = function() {
        var elements = document.getElementsByClassName('typewrite');
        for (var i=0; i<elements.length; i++) {
            var toRotate = elements[i].getAttribute('data-type');
            var period = elements[i].getAttribute('data-period');
            if (toRotate) {
              new TxtType(elements[i], JSON.parse(toRotate), period);
            }
        }
        // INJECT CSS
        var css = document.createElement("style");
        css.type = "text/css";
        css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
        document.body.appendChild(css);
    };

</script>

</html><?php /**PATH C:\Users\Mawuli\tuto\e-comm\resources\views/master.blade.php ENDPATH**/ ?>