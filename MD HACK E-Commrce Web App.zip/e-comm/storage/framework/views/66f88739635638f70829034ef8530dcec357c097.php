
<?php $__env->startSection('content'); ?>
    

<div class="custom-product custom-product-cart">
  
 <div class="col-sm-12">
   
    <div class="trending-wrapper">
        <h2 id="cart-user"><?php echo e(Session::get('user')['name']); ?> Orders</h2>
     
       
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class=" row searched-item cart-list-divider">
         <div class="col-sm-3">

            <a href="detail/<?php echo e($item->id); ?>">
                <img class="trending-img" src="<?php echo e($item->gallery); ?>">
            </a>
         </div>


         <div class="col-sm-6 cart-text">

           
                <div class="">
               
                 <h3>Name :<?php echo e($item->name); ?></h3>
                 <p>Delivery status :<?php echo e($item->status); ?></p>
                 <p>address :<?php echo e($item->address); ?></p>
                 <p>Payment Status :<?php echo e($item->payment_status); ?></p>
                 <p>Payment Method :<?php echo e($item->payment_method); ?></p>
                 
               
               </div>

         </div>


         
         
       </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>  
 </div>
       
</div>
        
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mawuli\tuto\e-comm\resources\views/myorders.blade.php ENDPATH**/ ?>