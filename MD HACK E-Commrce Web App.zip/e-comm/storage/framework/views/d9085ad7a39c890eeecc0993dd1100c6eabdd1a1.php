
<?php $__env->startSection('content'); ?>
    

<div class="custom-product custom-product-cart">
  
 <div class="col-sm-12">
   
    <div class="trending-wrapper">
        <h2 id="cart-user"><?php echo e(Session::get('user')['name']); ?> Cart Items</h2>
        <a href="ordernow"><button class="btn btn-success btn-order">Order Now</button></a>
       
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class=" row searched-item cart-list-divider">
         <div class="col-sm-3">

            <a href="detail/<?php echo e($item->id); ?>">
                <img class="trending-img" src="<?php echo e($item->gallery); ?>">
         </div>


         <div class="col-sm-6 cart-text">

            <a href="detail/<?php echo e($item->id); ?>">
               
                <h3><?php echo e($item->name); ?></h3>
               </a>
                <div class="">
               
                 <p><?php echo e($item->description); ?></p>
               
               </div>

         </div>


         <div class="col-sm-3 cart-remove">
               <a href="/removecart/<?php echo e($item->cart_id); ?>" class="btn btn-danger">Delete item </a>
         </div>

         
       </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <a href="ordernow"><button class="btn btn-success btn-order">Order Now</button></a>
    </div>  
 </div>
       
</div>
        
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mawuli\tuto\e-comm\resources\views/cartList.blade.php ENDPATH**/ ?>